### Hi there I am [Dilip](https://www.linkedin.com/in/dilip-patel-php)👋 
<br> 


### Languages and tools ⚙️ 
 <p> 
<img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/languages/html.svg" alt="html" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/languages/js.svg" alt="js" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/languages/python.svg" alt="python" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/frameworks/react.svg" alt="react" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/frameworks/vue.svg" alt="vue" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/misc/chrome.svg" alt="chrome" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/misc/cloud.svg" alt="cloud" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/services/aws.svg" alt="aws" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/services/npm.svg" alt="npm" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/services/gcp.svg" alt="gcp" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/tools/bash.svg" alt="bash" style="vertical-align:top; margin:4px"><img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/dev/tools/visualstudio_code.svg" alt="vscode" style="vertical-align:top; margin:4px">
</p> 


### Blogs 🌱 

<a hrefe="https://dev.to/dilippatel">
 <img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/blogs/devto.svg" alt="example badge" style="vertical-align:top margin:6px 4px"> 
</a> 
<a href=""> 
 <img src="https://raw.githubusercontent.com/dilippatel007/dilippatel007/master/svg/blogs/wordpress.svg" alt="example badge" style="vertical-align:top margin:6px 4px"> 
</a> 


### Social 
<a href="https://twitter.com/Dilip_S_Patel?s=09"> 
 <img align="left" alt="Dilip Patel| Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg"> 
</a> 
<a href="https://www.linkedin.com/in/dilip-patel-php"> 
 <img align="left" alt="Linkedin" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg"> 
</a> 
<a href="https://www.reddit.com/user/DilipPatel007"> 
 <img align="left" alt=" Reddit" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/reddit.svg"> 
</a> 
<br> 

<br> 


### My Github Stats 📊 

<br> 
  
[![Dilip's github stats](https://github-readme-stats.vercel.app/api?username=DilipPatel007&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515)](https://github.com/anuraghazra/github-readme-stats) 
  <!--
For future use
<a href="https://www.instagram.com/hemant.gz/">
  <img align="left" alt="Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />
</a>
<a href="https://leetcode.com//">
  <img align="left" alt="Leetcode" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/leetcode.svg" />
</a>
--> 



### ✨ My Recent Activity 
<!--START_SECTION:activity--> 
1. 🎉 
2. 💪 
3. 🎉 
4. 💪 
5. 🎉 
<!--END_SECTION:activity--> 




<br> 
<br> 
  
<!--
**DilipPatel007/dilippatel007** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
 

